"""
Practice 1
Name: 蕭登鴻
Student Number: 111502552
Course 2022-CE1003-B
"""

print('hello')
